#!/bin/sh
echo -ne '\033c\033]0;The Fifth Game of SwinkoSoft\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/anathema1.0" "$@"
